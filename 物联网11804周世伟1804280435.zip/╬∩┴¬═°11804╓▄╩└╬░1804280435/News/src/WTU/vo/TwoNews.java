package WTU.vo;

public class TwoNews {

}
