package WTU.vo;

public class Image {

}
