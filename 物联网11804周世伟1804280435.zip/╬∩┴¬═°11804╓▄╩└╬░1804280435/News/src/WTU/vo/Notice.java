package WTU.vo;

public class Notice {

}
