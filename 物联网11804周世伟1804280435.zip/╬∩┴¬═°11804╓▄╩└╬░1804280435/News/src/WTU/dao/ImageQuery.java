package WTU.dao;

public class ImageQuery {

}
